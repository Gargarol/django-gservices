=====
Gservices
=====

Gservices is a Django app to integrate google services into a Django application.

Quick start
-----------

1. Add "gservices" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'gservices',
    ]


